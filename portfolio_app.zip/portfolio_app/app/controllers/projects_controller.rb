class ProjectsController < ApplicationController
  def index
  end
end
