class ContactController < ApplicationController
  def index
    # Aquí puedes cargar datos si es necesario
  end

  def create
    # Aquí manejarás el envío del formulario
    flash[:notice] = "Mensaje enviado con éxito."
    redirect_to contact_path
  end
end
