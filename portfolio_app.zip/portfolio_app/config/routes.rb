Rails.application.routes.draw do
  root 'home#index' # Ruta raíz para /home
  get '/home', to: 'home#index'
  get '/projects', to: 'projects#index'
  get '/contact', to: 'contact#index'
  post 'contact', to: 'contact#create'
end

